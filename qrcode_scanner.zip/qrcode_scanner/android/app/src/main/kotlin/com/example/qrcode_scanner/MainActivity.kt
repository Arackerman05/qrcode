package com.example.qrcode_scanner

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
